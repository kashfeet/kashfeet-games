import asyncio
import pygame
import sys
import random

# --- Setup ---
pygame.init()
WIDTH, HEIGHT = 400, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Flappy Bird")
clock = pygame.time.Clock()
font = pygame.font.Font(None, 48)
small_font = pygame.font.Font(None, 32)

# --- Colors ---
SKY = (113, 197, 207)
GREEN = (106, 190, 48)
DARK_GREEN = (86, 150, 38)
YELLOW = (255, 216, 61)
ORANGE = (255, 140, 0)
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GROUND = (222, 216, 149)

# --- Constants ---
bird_x = 80
bird_size = 20
GRAVITY = 0.5
FLAP = -8
pipe_width = 60
pipe_gap = 150
pipe_speed = 3

# --- Game State ---
bird_y = HEIGHT // 2
bird_vel = 0
pipes = []
score = 0
game_over = False
spawn_timer = 0

def spawn_pipe():
    gap_y = random.randint(100, HEIGHT - 200)
    pipes.append({"x": WIDTH, "gap_y": gap_y, "scored": False})

async def main():
    global bird_y, bird_vel, pipes, score, game_over, spawn_timer

    bird_y = HEIGHT // 2
    bird_vel = 0
    pipes.clear()
    score = 0
    game_over = False
    spawn_timer = 0
    spawn_pipe()

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    if game_over:
                        bird_y = HEIGHT // 2
                        bird_vel = 0
                        pipes.clear()
                        score = 0
                        game_over = False
                        spawn_timer = 0
                        spawn_pipe()
                    else:
                        bird_vel = FLAP

        if not game_over:
            bird_vel += GRAVITY
            bird_y += bird_vel

            spawn_timer += 1
            if spawn_timer > 90:
                spawn_pipe()
                spawn_timer = 0

            for pipe in pipes:
                pipe["x"] -= pipe_speed

            for pipe in pipes[:]:
                if pipe["x"] + pipe_width < 0:
                    pipes.remove(pipe)
                elif not pipe["scored"] and pipe["x"] + pipe_width < bird_x:
                    pipe["scored"] = True
                    score += 1

            bird_rect = pygame.Rect(bird_x, bird_y, bird_size, bird_size)
            for pipe in pipes:
                top_rect = pygame.Rect(pipe["x"], 0, pipe_width, pipe["gap_y"])
                bottom_rect = pygame.Rect(pipe["x"], pipe["gap_y"] + pipe_gap, pipe_width, HEIGHT)
                if bird_rect.colliderect(top_rect) or bird_rect.colliderect(bottom_rect):
                    game_over = True

            if bird_y > HEIGHT - 50 or bird_y < 0:
                game_over = True

        screen.fill(SKY)

        for pipe in pipes:
            pygame.draw.rect(screen, GREEN, (pipe["x"], 0, pipe_width, pipe["gap_y"]))
            pygame.draw.rect(screen, DARK_GREEN, (pipe["x"] - 5, pipe["gap_y"] - 30, pipe_width + 10, 30))
            pygame.draw.rect(screen, GREEN, (pipe["x"], pipe["gap_y"] + pipe_gap, pipe_width, HEIGHT))
            pygame.draw.rect(screen, DARK_GREEN, (pipe["x"] - 5, pipe["gap_y"] + pipe_gap, pipe_width + 10, 30))

        pygame.draw.rect(screen, GROUND, (0, HEIGHT - 50, WIDTH, 50))
        pygame.draw.circle(screen, YELLOW, (bird_x, bird_y), bird_size)
        pygame.draw.circle(screen, BLACK, (bird_x + 6, bird_y - 4), 3)
        pygame.draw.polygon(screen, ORANGE, [
            (bird_x + bird_size, bird_y),
            (bird_x + bird_size + 10, bird_y + 4),
            (bird_x + bird_size, bird_y + 8)
        ])

        score_text = font.render(str(score), True, WHITE)
        screen.blit(score_text, (WIDTH // 2 - 15, 50))

        if game_over:
            over_text = font.render("Game Over", True, BLACK)
            restart_text = small_font.render("Press SPACE to restart", True, BLACK)
            screen.blit(over_text, (WIDTH // 2 - 100, HEIGHT // 2 - 40))
            screen.blit(restart_text, (WIDTH // 2 - 130, HEIGHT // 2 + 20))

        pygame.display.flip()
        clock.tick(60)
        await asyncio.sleep(0)

    pygame.quit()

asyncio.run(main())